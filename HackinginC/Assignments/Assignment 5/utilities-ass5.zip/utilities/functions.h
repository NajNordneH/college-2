#ifndef _HIC_FUNCTIONS_H
#define _HIC_FUNCTIONS_H

#include <stdint.h>

void print_address_little_endian(uintptr_t address);

#endif
